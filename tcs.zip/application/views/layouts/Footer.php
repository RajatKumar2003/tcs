<div class="footer">
              
              <div>
                  <strong><a href="https://digitalshakha.in/" class="text-dark" style="text-decoration: none; color: inherit;">Copyright @2024 Digital Shakha. All Rights Reserved</a></strong> 
              </div>
          </div>